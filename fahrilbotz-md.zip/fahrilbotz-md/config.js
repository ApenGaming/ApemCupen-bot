/* thank you to ALLAH Swt
tq nurutomo (mastah:v) 
tq ariffb (stikerin) (mastah:v) 
tq botolbotz (case aja sih:v) 
tq melcanz (case nya+doi nya banh ariffb:v) 
fahril (creator) 

awoakwkaka sc geratisan:v note : ada 3 file yang di enc dikit tu:v
*/
global.linkGC = ['https://chat.whatsapp.com/KewYr1eHLkyHFrwOZ8wafN', ''] // ganti jadi group lu
global.owner = ['6285876902820','6285876902820'] // Put your number here //owner eval
global.kontak = ['6285876902820','6285876902820'] //#owner
global.mods = ['6285876902820'] 
global.prems = ['6285876902820','6285876902820','6285876902820'] // Premium user
global.APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://nurutomo.herokuapp.com', 
  rey: 'https://server-api-rey.herokuapp.com',
  xteam: 'https://api.xteam.xyz',
  zahir: 'https://zahirr-web.herokuapp.com',
  lol: 'https://api.lolhuman.xyz',
  dhnjing: 'https://dhnjing.xyz',
  zeks: 'https://api.zeks.me',
  pencarikode: 'https://pencarikode.xyz',
  LeysCoder: 'https://leyscoders-api.herokuapp.com'
}
global.APIKeys = { // APIKey Here
  'https://server-api-rey.herokuapp.com': 'apirey',
  'https://api.xteam.xyz': 'cb15ed422c71a2fb',
  'https://api.lolhuman.xyz': 'fahrilkey21',
  'https://zahirr-web.herokuapp.com': 'zahirgans',
  'https://api.zeks.me': 'apivinz',
  'https://pencarikode.xyz': 'pais',
  'https://leyscoders-api.herokuapp.com': 'dappakntlll'
} //note sc gw enc beberapa di plugins dll ada lumayan kallo mau yang no enc beli //30k udah dapet N0 enc 100% ke wa.me/6285876902820

lolkey = 'fahrilkey2,1'//habis apikey lolhuman gw:v
zekskey = 'apivinz'
xteamkey = 'Dawnfrostkey'

namaig = 'fahril ahmad'
namagithub = 'Fahrilahmad'
kasihcaption = `Nih kak`
namakontak1 = 'fahril one'
namakontak2 = 'fahril two'
caption = 'Nih Kak'

// Sticker WM
global.packname = 'By fahril'
global.author = 'fahrilbotz'


bc = 'fahrilbotz' //Broadcast
footer = '\n©fahril'
namabot = 'fahrilbotz'
namalu = 'fahril'


// 
wait = 'wait kak!'
global.wait = 'wait kak!'
global.rpg = 'Fitur Rpg Dimatikan oleh owner!'
global.nsfw = 'Fitur NSFW Dimatikan oleh owner!'
global.eror = '_*Server Error*_'

global.fla = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text='
global.image = 'https://telegra.ph/file/e2a9c1963a04a2f6f3c02.jpg'

global.multiplier = 36 // The higher

//--------(🗿 )----------\\
let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})

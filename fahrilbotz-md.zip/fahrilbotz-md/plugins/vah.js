let handler  = async (m, { conn, usedPrefix: _p }) => {
kontol = `@${m.sender.split`@`[0]}`
let info = `Hai ${kontol} nih sc via github : github.com/fahrilahmad
`.trim()

conn.fakeReply(m.chat, info, '0@s.whatsapp.net', `*${global.packname}*`, 'status@broadcast') 
}
handler.help = ['github']
handler.tags = ['info']
handler.command = ['script', 'sc', 'scbot', 'github']
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 25

module.exports = handler

//gosah ganti lu juga make sc free awoakwoaka
//ini juga di enc jadi sedekah aja:v
let fetch = require('node-fetch')
let handler = async (m, { conn }) => await conn.sendButtonLoc(m.chat,
await (await fetch(fla + 'List anime')).buffer(), `
       『LIST ANIME』
${readMore}
1. golden time ( kaga kouko & Tada Banri )
2. Charlotte ( Yuu Otasaka )
3. High School DxD ( Issei & rias )
4. Black Clover ( Asta & Noelle )
5. Haikyuu!! ( Volly ) Hinata & Kageyama
6. Tonikaku kawaii
7. Horimiya ( Miyamura & Hori ) 
8. The Daily Life of the immortal king, Wang ling
9. Noblesse
10. Hyouka
11. Isekai Maou Shoukon Shoujo
12. Jujutsu kaisen 
13. The God high School
14. The devil is a part 
15. Sidetektif Sudah mati
16. assassination Classroom
17. Welcome to demon school! ( Iruma Kun )
18. One Piece
19. Boruto
20. Battle Game in 5 second
21. Kengan Ashura
22. A Certain Magical Index
23. Higehiro, Siswi Sma Kupungut
24. Masamune Kun No Revenge
25. Ao Haru Ride ( Kou & Futaba )
26. Yosuga No Sora
27. Kiss X Sis
28. Nanatzu No Taizai ( Meliodas )
29. Record Of Ragnarok
30. Boku No Hero


DAFTAR ANIME


[ GENRE ACTION ]
1. Kill La Kill
2. Akame Ga Kill 
3. Saiki Kauso 
4. Black Butler 
5. Belzeebub
6. UQ Holder 
7. Charlote
8. Dies Irae 
9. Isekai Maou 
10. Hataraku Maou Sama 
11. Isekai Wa Smartphone
12. Kekkai Sensen
13. Code Geass
14. God Eater 
15. Darling In Fanxx
16. Mirai Nikki 
17. Hellsing ultimete
18. Radiant
19. Gulity Crown 
20. Knight And Magic 
21. Youjo Senki
22. Re:Zero Kara Hajimeru Isekai Seikatsu
23. Sword Art Online
24. No Game No Life
25. Death March
26. Log Horizon
27. Mondaiji
28. Ushio To Tora 
29. Overlord 
30. Big Order 
31. Mahouka koukou 
32. Re : Creator 
33. Kyokai No Kanata
34. Date Alive 
35. Magi Series 
36. Rokudenashi majutsu 
37. Owari No Sherap
38. Gakusen Tosh Asterisk 
39. Shinmai Maou No Testament 
40. Kiseiju
41. Dead Note 
42. Sakamoto Desu Ga
43. Rosario Vampire 
44. Shingeki No Kyojin 
45. Classroom Of The Elite 
46. Tensei Shitara Slime datta ken 
47. Noragami
48. Mob Psycho 
49. Sousei No onmyouji
50. Hai to Gensou No Grimgar 

[ GENRE ROMANCE ] 
1. White Album 
2. White Album 2
3. golden time 
4. Bokura ga ita
5. Hachimitsu to clover
6. ao haru ride
7. Kokoro connet 
8. Relife 
9. Clannad 
10. Shigatsu wa kimi no uso
11. Orange
12. True tears
13. Plastic memories
14. Hanbun no tsuki ga noboru sora
15. Tsuki ga kirei
16. Koi to uso
17. Fukumenkei noise
18. Kimi no todoke
19. Toradora 
20. Sakuraso no pet na kanojo
21. Oreimo
22. Zutto mae kara suki deshita 
23. Suki ni naru shunkan wo
24. 5 cm per second 
25. Kotonaha no niwa
26. Koe no katachi 
27. Aishiteru ze baby?
28. Kyokai na kanata
29. Kumou no muko ya kusoku no basho 
30. Isshuukan friends 
31. Anonatsu de matteru 
32. Chuunibyou demo shina kata:ren
33. Koi kaze 
34. Angel beast
35. Guilty crown 
36. Sukitteli na yo
37. Re: zero kara hajimeru isekai seikatsu
38. Itazura no kiss 
39. Kimi no nawa
40. Anohana
41. Kanon
42. Hyouka 
43. Air
44. The ocean waves
45. Ef : a tales of memories 
46. Shakugan no shana 
47. Kimi no iru machi
48. Mashiro iro symphony 
49. Hanasaku iroha 
50. Suka suka
51. Ef : a tale of melodies 
52. Sakamichi no apollon


[ GENRE COMEDY ]
1. Asobi asobase 
2. Beelzebub
3. Himotou umaru-chan
4. Great Teacher Onizuka
5. Working!! Series
6. SKET Dance 
7. Danshi koukousei no nichijou
8. Prison School


[ GENRE MYSTERY ]
1. Death note 
2. Another
3. Gosick 
4. Boku Dake Ga inai machi 
5. Detective conan
6. Sakurako-san no ashimoto ni wa shitai ga 
7. Umatteiru 
8. Subete ga F ni naru: the perfect insider 


[ GENRE PSYCHOLOGICAL ]
1. Monster
2. Ghost in the shell
3. Kokkoku 
4. Mawaru penguindrum 
5. Elfed lied
6. Kanojo to kanojo no neko:everything flows
7. Youkoso jitsuryaku shijou shugi no kyoushitsu e
8. Zetzuen no tempest 
9. Zankyou no terror
10. Inuyashiki
11. Jigoku shoujo
12. Kakegurui 
13. Death parade 
14. Danganronpa
15. ChäoS;HEAd
16. Psycho pass
17. Tokyo ghoul 
18. Gantz:O
19. Btooom!
20. Death note 
21. Mirai nikki 
22. Ping pong the animation
23. Re:zero kara hajimeru isekai seikatsu
24. Kiseijuu:sei no kakuritsu
25. Boku dake ga inai machi (erased)


[ GENRE ADVENTURE ]
1. Kino no Tabi: the beautiful world
2. Ookami to khousinryou (spice and wolf)
3. Howl no ugoku shiro (howl's moving castle)


[ GENRE DRAMA ]
1. Sankarea
2. Yahari ore no seishun love come wa mac higatteiru
3. Ano hi mita hana no namae wo bokutachi wa mada shiranai 
4. Clannad series 
5. Glasslip


[ GENRE SLICE OF LIFE ]
1. Dagashi kashi 
2. Himouto! Umaru-chan 
3. Servant x Service 
4. Non Non Biyori
5. Usagi Drop
6. New Game! 


[ GENRE FANTASY ]
1. Gate: jietai kanochi Nite, kaku Tatakaeri 
2. Shingenki No bahamut Series
3. Konosoba 
4. Nanatzu No Taizai
5. Magi Series 


[ GENRE MAGIC ]
1. Rokudenashi Majutsu Koushi to akashic Records 
2. Fate Series
3. Fairy Tail 
4. Amagi Brilliant Park
5. Junketsu no Maria
6. Black Clover


[ GENRE YAOI AND YURI ]
1. Junjou Romantica
2. Loveless
3. Super Lovers
4. Love Stage 
5. Hyakujitsu no Bara 
6. Maria Sama ga Miteru 
7. Aoi Hana
8. Yuru Yuri
9. Maria Holic 
10. Sakura Trick 


[ GENRE TRAGEDY ] 
1. Mawaru Penguindrum 
2. Mahou Shoujo Madoka Magica
3. Hoshi No Koe 
4. True Tears 
5. Tokyo Magnitude 8.0


[ GENRE SHOUNEN,SHOUJO,SEINEN ]
1. Katetyo Hitman Reborn!
2. Bakuman.
3. Beelzebub
4. School Rumble
5. D. Gray-Man
6. Soredemo sekai wa utsukushii
7. Sabage-bu!
8. Nijiro Days 
9. Donten Ni warau 
10. Free!
11. Ajin
12. Black Bullet 
13. Baccano!
14. Sakamoto Desu-ga?
15. Elfend lied


[ GENRE ISEKAI ]
1. Re:zero kara Hajimeru Isekai Seikatsu
2. Swort Art Online 
3. No Game no life 
4. Overlord 
5. Hai to Gensou no Grimgar 
6. Isekai wa smartphone to tomo ni
7. Death march 
8. Log horizon 
9. Mondaiji tachi
10. How to sommon demon lord?
11. Knight & magic
12. Outbreak company


[ GENRE ECCHI ]
1. High School DxD
2. Kanokon
3. Shimoneta to iu Gainen ga Sonzai Shinai Taikutzu na Sekai 
4. B Gata H Kei
5. Shinmai maou no Testament
6. Yosuga No Sora
7. Kiss X Sis
`.trim(), 'SELAMAT MENONTON ANIME', 'MENU', '.m', m)

handler.help = ['listanime']
handler.tags = ['internet', 'anime', 'fun']

handler.command = /^(listanime)$/i
  
module.exports = handler
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
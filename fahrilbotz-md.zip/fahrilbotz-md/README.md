<h1 align="center">Hi! saya fahrilbotz</h1>

<p align="center">
  <a href="https://ibb.co/QQX130c"><img src="http://readme-typing-svg.herokuapp.com?color=1C71FA&center=true&vCenter=true&multiline=false&lines=saya+fahril+dari+Indonesia.;saya+gakpapa:)" alt="fahril">
</p>

<p align="left">
  <img src="https://komarev.com/ghpvc/?username=MichaelAgam&color=blue&style=flat-square&label=Profile+Views" alt="Profile Views" /> <img src="https://img.shields.io/github/followers/MichaelAgam23?label=fahrilbotz" style=" float:left, margin-right:10px" alt="Followers" />
</p>


# fahrilbotz
Simple Rpg WhatsApp Bot fahrilbotz

<a href="https://github.com/Dawnfrosty/Mike-bot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Dawnfrosty/Mike-bot?label=Forks&color=blue&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/Dawnfrosty/Mike-bot?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/Dawnfrosty/Mike-bot?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/graphs/contributors"><img title="Contributors" src="https://img.shields.io/github/contributors/Dawnfrosty/Mike-bot?label=Contributors&color=blue&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/issues"><img title="Issues" src="https://img.shields.io/github/issues/Dawnfrosty/Mike-bot?label=Issues&color=success&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/issues?q=is%3Aissue+is%3Aclosed"><img title="Issues" src="https://img.shields.io/github/issues-closed/Dawnfrosty/Mike-bot?label=Issues&color=red&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/pulls"><img title="Pull Request" src="https://img.shields.io/github/issues-pr/Dawnfrosty/Mike-bot?label=PullRequest&color=success&style=flat-square"></a>
<a href="https://github.com/Dawnfrosty/Mike-bot/pulls?q=is%3Apr+is%3Aclosed"><img title="Pull Request" src="https://img.shields.io/github/issues-pr-closed/Dawnfrosty/Mike-bot?label=PullRequest&color=red&style=flat-square"></a>

## Join Group
[![Grup WhatsApp](https://chat.whatsapp.com/KewYr1eHLkyHFrwOZ8wafN)]() 
**bebas masukin bot**

## Deploy to heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Dawnfrosty/Mike-bot)

❄1�7 Heroku Buildpack ❄1�7
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/DuckyTeam/heroku-buildpack-imagemagick

## UNTUK TERMUX/UBUNTU

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
apt install imagemagick -y
git clone (link yg lu salin) 
cd (nama file) 
npm install
npm update
```
---------

## UNTUK WINDOWS/VPS/RDP USER

* Download And Install Git [`klik disini`](https://git-scm.com/downloads)
* Download And Install NodeJS [`klik disini`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`klik disini`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`klik disini`](https://imagemagick.org/script/download.php)

```bash
git clone (link yg lu salin) 
cd (nama file lu) 
npm install
npm update
```

---------

## done

```bash
node .
```

---------
